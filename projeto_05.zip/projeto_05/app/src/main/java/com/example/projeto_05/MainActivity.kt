package com.example.projeto_05

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import com.dvoiss.literallytoast.LitToast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        listView.adapter = adapter
        button.setOnClickListener{
            if (editText.text.isNotEmpty()) {
                adapter.add(editText.text.toString())
                editText.text.clear()
            } else {
                editText.error = "You should not pass!!"
            }
        }

        listView.setOnItemClickListener{ parent, view, position, id ->
            val item = adapter.getItem(position)
//            Toast.makeText(applicationContext, "Voce clicou em ${item}", Toast.LENGTH_SHORT).show()
            LitToast.create(this, "Voce clicou em ${item}", 1500)
                .setPlayToasterSound(true)
                .show();
            true
        }

        listView.setOnItemLongClickListener{ parent, view, position, id ->
            adapter.remove(adapter.getItem(position))
            
            true
        }
    }
}
