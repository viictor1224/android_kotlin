package com.example.projeto_2

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*


data class Produto(val id : Int, val nome : String, var preco : Double,
                   var descricao : String)

fun mostrarProduto(produto : Produto):String {
    var retorno = "ID : ${produto.id}\t"
    retorno += "NOME : ${produto.nome}\t"
    retorno += "PREÇO : ${produto.preco}\n"
    retorno += "DESCRIÇÃO : ${produto.descricao}\n"
    return retorno
}

class MainActivity : AppCompatActivity() {

    val produtos = ArrayList<Produto>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun pegarDados(view : View){
        val produto = Produto(
            etId.text.toString().toInt(),
            etNome.text.toString(),
            etPreco.text.toString().toDouble(),
            etDescricao.text.toString()
        )
        produtos.add(produto)
        var saida = "Resultado:\n"
        for (prod in produtos) {
            saida += mostrarProduto(prod)
        }
        textView2.text = saida
    }
}
